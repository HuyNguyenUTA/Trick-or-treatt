//Huy Nguyen
//1001744707
package code6_1001744707;

import javax.swing.JFrame;

public class Code6_1001744707 
{
    public static void main(String[] args) {
        Password password = new Password();
        password.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        password.setSize(400, 200);
        password.setVisible(true);
    }
    
}
